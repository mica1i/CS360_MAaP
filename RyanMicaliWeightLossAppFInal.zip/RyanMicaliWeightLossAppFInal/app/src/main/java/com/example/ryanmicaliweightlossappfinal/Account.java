package com.example.ryanmicaliweightlossappfinal;

import java.util.ArrayList;

public class Account {

    public static ArrayList<Account> accountArrayList = new ArrayList<>();

    private int accountId;
    private String username;
    private String password;

    public Account(int accountId, String username, String password) {
        this.accountId = accountId;
        this.username = username;
        this.password = password;
    }

    public int getAccountId() {
        return accountId;
    }

    public void setAccountId(int accountId) {
        this.accountId = accountId;
    }

    public static String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
