package com.example.ryanmicaliweightlossappfinal;

import java.util.ArrayList;
import java.util.Date;

public class Entry {

    public static ArrayList<Entry> entryArrayList = new ArrayList<>();

    private int entryId;
    private String weight;
    private String goal;
    private Date deleted;

    public Entry(int entryId, String weight, String goal, Date deleted) {
        this.entryId = entryId;
        this.weight = weight;
        this.goal = goal;
        this.deleted = deleted;
    }

    public Entry(int entryId, String weight, String goal) {
        this.entryId = entryId;
        this.weight = weight;
        this.goal = goal;
        deleted = null;
    }

    public int getEntryId() {
        return entryId;
    }

    public void setEntryId(int entryId) {
        this.entryId = entryId;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getGoal() {
        return goal;
    }

    public void setGoal(String goal) {
        this.goal = goal;
    }

    public Date getDeleted() {
        return deleted;
    }

    public void setDeleted(Date deleted) {
        this.deleted = deleted;
    }
}
