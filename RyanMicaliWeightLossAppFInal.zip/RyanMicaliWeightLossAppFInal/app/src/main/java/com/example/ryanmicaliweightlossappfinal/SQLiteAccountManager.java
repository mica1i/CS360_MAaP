package com.example.ryanmicaliweightlossappfinal;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SQLiteAccountManager extends SQLiteOpenHelper {

    private static SQLiteManager sqliteManager;
    private static final String DATABASE_NAME = "AccountDB";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "Account List";
    private static final String COUNTER = "Counter";

    private static final String ACCOUNT_ID_FIELD = "accountId";
    private static final String USERNAME_FIELD = "username";
    private static final String PASSWORD_FIELD = "password";


    public SQLiteAccountManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    public static SQLiteManager instanceOfDatabase(Context context){
        if (sqliteManager == null) {
            sqliteManager = new SQLiteManager(context);

        }
        return sqliteManager;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        StringBuilder sql;
        sql = new StringBuilder()
                .append("CREATE TABLE ")
                .append(TABLE_NAME)
                .append("(")
                .append(COUNTER)
                .append("INT PRIMARY INCREMENT")
                .append(ACCOUNT_ID_FIELD)
                .append(" INT, ")
                .append(USERNAME_FIELD)
                .append(" TEXT, ")
                .append(PASSWORD_FIELD)
                .append(" TEXT, ");
        sqLiteDatabase.execSQL(sql.toString());
    }


    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
//        switch (oldVersion)
//        {
//            case 1:
//                return;
//        }
    }

    public void addAccountToDatabase(Account account) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(ACCOUNT_ID_FIELD, account.getAccountId());
        contentValues.put(USERNAME_FIELD, account.getUsername());
        contentValues.put(PASSWORD_FIELD, account.getPassword());

        sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
    }

    // repopulate memory
    public void populateAccountListArray() {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();

        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + TABLE_NAME, null)){
            if (result.getCount() != 0) {
                while (result.moveToNext()) {
                    int id = result.getInt(1);
                    String username = result.getString(2);
                    String password = result.getString(3);
                    // FIX ME
                    Account account = new Account(accountId, username, password);
                    Account.accountArrayList.add(account);
                }

            }
        }
    }

    public void updateAccountInDB(Account account) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(ACCOUNT_ID_FIELD, account.getAccountId());
        contentValues.put(USERNAME_FIELD, account.getUsername());
        contentValues.put(PASSWORD_FIELD, account.getPassword());

        sqLiteDatabase.update(TABLE_NAME, contentValues, ACCOUNT_ID_FIELD + "=?", new String[]{String.valueOf(account.getAccountId())});
    }



}
