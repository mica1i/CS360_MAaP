package com.example.ryanmicaliweightlossappfinal;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;


public class MainActivity extends AppCompatActivity {


    private AccountAdapter sqLiteAdapter;

    // references to buttons on layout

    Button login_btn, new_act_btn, sms_btn, settings_btn, submit_btn;
    EditText et_username;
    EditText et_pass;
    EditText et_weight;
    EditText et_goal;
    ListView weight_table;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login_btn = findViewById(R.id.LogIn);
        new_act_btn = findViewById(R.id.createNewAccount);
        et_username = findViewById(R.id.UsernameInput);
        et_pass = findViewById(R.id.passwordBox);

        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AttemptLogin();
                Toast.makeText(MainActivity.this, "Login", Toast.LENGTH_SHORT).show();

               // FIX ME
                if (login = true) {
                    setContentView(R.layout.tracker);
                }
            }
        });

        new_act_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "New Account", Toast.LENGTH_SHORT).show();
            }

            // FIX ME
            if (new_act_btn.OnClickListener = true) {
                addAccountToDB();
                updateAccountInDB();
            }

        });

    }

    public void AttemptLogin() {
        String username = et_username.getText().toString();
        String passwordInput = et_pass.getText().toString();
        Cursor c = AccountAdapter.getUsername(username);

        if(c.getCount() == 0)
        {
            Toast.makeText(getApplicationContext(), "User name does not exist",
                    Toast.LENGTH_LONG).show();
            et_username.setText("");
            et_pass.setText("");
            return;
        }


        // FIX ME

        if(et_pass = password)
        {
            username.setAccountId(c.getInt(0));
            username.setUsername(username);
            username.setUserAdmin(true);
            // Login
            Intent i = new Intent(this, MainActivity.class);
            startActivity(i);
            finish();
        }
        else
        {
            Toast.makeText(getApplicationContext(), "Incorrect password",
                    Toast.LENGTH_LONG).show();
            et_pass.setText("");
            return;
        }


    }

}
