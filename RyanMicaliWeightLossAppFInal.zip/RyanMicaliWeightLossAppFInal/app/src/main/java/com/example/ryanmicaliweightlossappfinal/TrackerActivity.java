package com.example.ryanmicaliweightlossappfinal;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Date;


public class TrackerActivity extends MainActivity {

    private ListView entryListView;
    private Entry selectedEntry;
    private Button deleteButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tracker);
        initWidgets();
        loadFromDBToMemory();
        setEntryAdapter();
    }

    private void initWidgets() {
        et_weight = findViewById(R.id.weight);
        et_goal = findViewById(R.id.goal);
        entryListView = findViewById(R.id.entryListView);
        deleteButton = findViewById(R.id.clear_data);
    }

    private void loadFromDBToMemory() {
        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);
        sqLiteManager.populateEntryListArray();
    }

    private void setEntryAdapter() {
        EntryAdapter entryAdapter = new EntryAdapter(getApplicationContext(), Entry.entryArrayList);
        entryListView.setAdapter(entryAdapter);
    }

    private void saveEntry(View view) {
        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);
        String weight = String.valueOf(et_weight.getText());
        String goal = String.valueOf(et_goal.getText());

        int entryId = Entry.entryArrayList.size();
        Entry newEntry = new Entry(entryId, weight, goal);
        Entry.entryArrayList.add(newEntry);
        sqLiteManager.addEntryToDatabase(newEntry);

        if (et_weight == null) {
            Entry.entryArrayList.add(newEntry);
            sqLiteManager.addEntryToDatabase(newEntry);
        }
        else {
            selectedEntry.setWeight(weight);
            selectedEntry.setGoal(goal);
            sqLiteManager.updateEntryInDB(selectedEntry);
        }

        finish();

    }

    public void deleteList(View view) {
        selectedEntry.setDeleted(new Date());
        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);
        sqLiteManager.updateEntryInDB(selectedEntry);
        finish();
    }
}
