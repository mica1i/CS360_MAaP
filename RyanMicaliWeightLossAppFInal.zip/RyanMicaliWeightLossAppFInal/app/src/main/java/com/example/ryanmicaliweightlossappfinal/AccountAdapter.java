package com.example.ryanmicaliweightlossappfinal;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class AccountAdapter extends ArrayAdapter<Account> {
    public AccountAdapter (Context context, List<Account> accounts) {
        super(context, 0, accounts);
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Account account = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.table_cell, parent, false);


            TextView username = convertView.findViewById(R.id.UsernameInput);
            TextView password = convertView.findViewById(R.id.passwordBox);

            assert account != null;

            username.setText(account.getUsername());
            password.setText(account.getPassword());

            return convertView;
        }
        return convertView;
    }
}
