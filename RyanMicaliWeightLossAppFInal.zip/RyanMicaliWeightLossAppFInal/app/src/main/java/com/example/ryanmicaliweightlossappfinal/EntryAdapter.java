package com.example.ryanmicaliweightlossappfinal;



import android.content.Context;
import android.security.identity.CredentialDataResult;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class EntryAdapter extends ArrayAdapter<Entry> {
    public EntryAdapter (Context context, List<Entry> entries) {
        super(context, 0, entries);
    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Entry entry = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.table_cell, parent, false);

            TextView weight = convertView.findViewById(R.id.weight);
            TextView date = convertView.findViewById(R.id.date);
            TextView goal = convertView.findViewById(R.id.goal);

            assert entry != null;
            weight.setText(entry.getWeight());
            //date.setText(entry.getDeleted());
            goal.setText(entry.getGoal());

            return convertView;
        }
        return convertView;
    }
}
