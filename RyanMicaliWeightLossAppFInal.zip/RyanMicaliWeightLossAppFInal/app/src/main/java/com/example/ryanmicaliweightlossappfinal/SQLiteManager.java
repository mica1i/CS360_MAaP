package com.example.ryanmicaliweightlossappfinal;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SQLiteManager extends SQLiteOpenHelper {

    private static SQLiteManager sqliteManager;
    private static final String DATABASE_NAME = "EntryDB";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "Weight Table";
    private static final String COUNTER = "Counter";

    private static final String ID_FIELD = "entryId";
    private static final String WEIGHT_FIELD = "weight";
    private static final String GOAL_FIELD = "goal";
    private static final String DELETED_FIELD = "deleted";

    @SuppressLint("SimpleDateFormat")
    private static final DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");


    public SQLiteManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    public static SQLiteManager instanceOfDatabase(Context context){
        if (sqliteManager == null) {
            sqliteManager = new SQLiteManager(context);

        }
        return sqliteManager;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        StringBuilder sql;
        sql = new StringBuilder()
                .append("CREATE TABLE ")
                .append(TABLE_NAME)
                .append("(")
                .append(COUNTER)
                .append("INT PRIMARY INCREMENT")
                .append(ID_FIELD)
                .append(" INT, ")
                .append(WEIGHT_FIELD)
                .append(" TEXT, ")
                .append(GOAL_FIELD)
                .append(" TEXT, ")
                .append(DELETED_FIELD)
                .append(" TEXT ");
        sqLiteDatabase.execSQL(sql.toString());
    }


    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
//        switch (oldVersion)
//        {
//            case 1:
//                return;
//        }
    }

    public void addEntryToDatabase(Entry entry) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, entry.getEntryId());
        contentValues.put(WEIGHT_FIELD, entry.getWeight());
        contentValues.put(GOAL_FIELD, entry.getGoal());
        contentValues.put(DELETED_FIELD, getStringFromDate(entry.getDeleted()));

        sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
    }

    // repopulate memory
    public void populateEntryListArray() {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();

        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + TABLE_NAME, null)){
            if (result.getCount() != 0) {
                while (result.moveToNext()) {
                    int id = result.getInt(1);
                    String weight = result.getString(2);
                    String goal = result.getString(3);
                    String stringDeleted = result.getString(4);
                    Date deleted = getDateFromString(stringDeleted);
                    Entry entry = new Entry(id, weight, goal, deleted);
                    Entry.entryArrayList.add(entry);
                }

            }
        }
    }

    public void updateEntryInDB(Entry entry) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, entry.getEntryId());
        contentValues.put(WEIGHT_FIELD, entry.getWeight());
        contentValues.put(GOAL_FIELD, entry.getGoal());
        contentValues.put(DELETED_FIELD, getStringFromDate(entry.getDeleted()));

        sqLiteDatabase.update(TABLE_NAME, contentValues, ID_FIELD + "=?", new String[]{String.valueOf(entry.getEntryId())});
    }

    private String getStringFromDate(Date date) {
        if (date == null)
            return null;
        return dateFormat.format(date);
    }

    private Date getDateFromString(String string)   {
        try
        {
            return dateFormat.parse(string);
        }
        catch (ParseException | NullPointerException e)
        {
            e.printStackTrace();
        }

        return null;
    }


}
